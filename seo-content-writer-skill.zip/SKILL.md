---
name: seo-content-writer
description: A skill for creating high-quality, SEO-optimized content by analyzing top search results and generating articles that are comprehensive and well-structured.
version: 1.0.0
license: Proprietary
metadata: {"openclaw":{"requires":{"env":[],"bins":["curl", "python3"]},"primaryEnv":"","emoji":"✍️"}}
---

# SEO Content Writer

## When to activate

**Keywords:**
- SEO content
- Blog post writing
- Article writing
- Content creation
- SEO-optimized article
- Write an article for me
- Content marketing
- On-page SEO
- Keyword research
- SERP analysis
- Content strategy
- High-quality content
- Long-form content
- SEO writing assistant
- Generate a blog post
- Write a product review
- Create a how-to guide
- Informational article
- Transactional content
- Navigational content
- LSI keywords
- Topic clusters
- Pillar pages
- Skyscraper technique
- Content gap analysis

**Scenarios:**
- A user wants to rank higher on Google for a specific keyword.
- A user needs a blog post for their company's website.
- A user wants to create a comprehensive guide on a particular topic.
- A user needs help with their content marketing efforts.
- A user wants to rewrite an existing article to be more SEO-friendly.
- A user needs a product review that will attract organic traffic.
- A user wants to create a series of articles around a central theme (topic cluster).
- A user needs to generate a long-form article to establish authority in their niche.
- A user wants to analyze the top-ranking articles for a keyword and create something better.
- A user needs to create content for a new website and wants to optimize it for search engines from the start.
- A user wants to update an old blog post with fresh information and better SEO.
- A user needs to create a script for a YouTube video that is optimized for search.

## Workflow

The agent will follow a structured workflow to ensure the creation of high-quality, SEO-optimized content. The process is divided into five main phases:

**Phase 1: Topic Analysis and Keyword Research**

1.  **Understand the User's Request:** The agent will first analyze the user's prompt to understand the core topic, target audience, desired tone, and any specific requirements.
2.  **Initial Keyword Research:** The agent will use the `search` tool with the `info` type to identify a primary keyword and a set of related secondary and LSI (Latent Semantic Indexing) keywords. This will involve queries like `"top keywords for [topic]"` or `"related keywords for [primary keyword]"`.
3.  **Keyword Validation:** The agent will use the `search` tool again to validate the chosen keywords, looking for search volume and competition. The agent will analyze the search results to understand the intent behind the keywords (informational, transactional, or navigational).

**Phase 2: SERP Analysis**

1.  **Analyze Top-Ranking Content:** The agent will perform a Google search for the primary keyword and analyze the top 5-10 ranking articles. The agent will use the `browser` tool to visit each of these URLs.
2.  **Extract Key Information:** For each article, the agent will extract the following information:
    *   Title and meta description
    *   Headings and subheadings (H1, H2, H3)
    *   Main topics and sub-topics covered
    *   Word count
    *   Use of images, videos, and other media
    *   Internal and external links
    *   Overall structure and format
3.  **Synthesize Findings:** The agent will synthesize the extracted information into a summary document. This document will highlight common themes, content gaps, and opportunities to create a more comprehensive and valuable piece of content.

**Phase 3: Content Outline Generation**

1.  **Create a Detailed Outline:** Based on the SERP analysis, the agent will create a detailed outline for the new article. This outline will include:
    *   A compelling, SEO-friendly title
    *   A meta description that encourages clicks
    *   A logical structure of headings and subheadings
    *   Bullet points for key topics to be covered in each section
2.  **Incorporate Keywords:** The agent will strategically incorporate the primary and secondary keywords into the outline, particularly in the title and headings.

**Phase 4: Content Drafting**

1.  **Write the Introduction:** The agent will write a captivating introduction that hooks the reader and clearly states the article's purpose.
2.  **Draft the Body Paragraphs:** The agent will write the body of the article, following the outline and ensuring a smooth flow of information. The agent will focus on providing value to the reader by being clear, concise, and comprehensive.
3.  **Write the Conclusion:** The agent will write a strong conclusion that summarizes the main points and provides a clear call-to-action (if applicable).
4.  **Cite Sources:** The agent will properly cite any sources used for information, statistics, or quotes.

**Phase 5: Optimization and Refinement**

1.  **On-Page SEO:** The agent will optimize the article for on-page SEO factors, including:
    *   Keyword density
    *   Internal linking to other relevant articles on the user's website (if provided)
    *   External linking to authoritative sources
    *   Image alt text (if images are included)
2.  **Readability:** The agent will ensure the article is easy to read by using short sentences and paragraphs, bullet points, and bold text to break up the content.
3.  **Final Review:** The agent will perform a final review of the article to check for grammar, spelling, and factual errors.

## Guardrails

1.  **No Plagiarism:** The agent MUST NOT plagiarize content from other sources. All content must be original and written in the agent's own words. Direct quotes must be properly attributed.
2.  **Fact-Checking:** The agent MUST verify all facts, statistics, and data from credible sources. The agent should cite the sources used.
3.  **No Paid Tools:** The agent MUST NOT use any third-party APIs or paid services for keyword research or content analysis. All tasks must be performed using the agent's built-in tools.
4.  **User-Centric Content:** The primary focus of the content should be to provide value to the reader. The agent should avoid keyword stuffing and other black-hat SEO techniques.
5.  **Respect Copyright:** The agent MUST NOT use copyrighted images or media without permission. The agent should use royalty-free images or create its own visuals.
6.  **Maintain a Neutral Tone:** Unless otherwise specified by the user, the agent should maintain a neutral and objective tone in the writing.
7.  **No Medical or Legal Advice:** The agent MUST NOT provide medical or legal advice. For such topics, the agent should include a disclaimer advising the reader to consult a professional.
8.  **Follow User's Instructions:** The agent MUST adhere to all specific instructions and requirements provided by the user.
9.  **Data Privacy:** The agent MUST NOT ask for or store any personal or sensitive information from the user.
10. **Clarity and Simplicity:** The agent should strive to explain complex topics in a clear and simple manner, avoiding jargon where possible.

## Failure handling

| Error Condition | Detection | Recovery Action |
| :--- | :--- | :--- |
| Website is blocking the browser | The `browser` tool returns an error or an empty page. | The agent will try to access the cached version of the page via a search engine, or it will look for an alternative source of information. |
| Inability to find sufficient information | The `search` tool returns few or no relevant results. | The agent will broaden the search queries, try different keyword variations, or break down the topic into smaller sub-topics. |
| Keyword is too competitive | The SERP analysis reveals that the top-ranking pages are from very high-authority domains. | The agent will suggest a long-tail keyword variation that is less competitive but still relevant to the user's topic. |
| User is not satisfied with the draft | The user provides feedback indicating that the content does not meet their expectations. | The agent will carefully review the user's feedback, ask clarifying questions, and revise the content accordingly. |
| Content is factually incorrect | The user or a third-party points out a factual error in the content. | The agent will immediately correct the error, verify the new information from a credible source, and apologize for the mistake. |

## Real-world use cases

1.  **A small business owner wants to increase organic traffic to their website.** They use the SEO Content Writer skill to create a series of blog posts on topics related to their industry. The agent helps them identify relevant keywords, analyze the competition, and write high-quality articles that attract and engage their target audience.
2.  **A marketing manager needs to create a pillar page for a new content marketing campaign.** They use the skill to create a comprehensive, long-form guide on a broad topic. The agent helps them structure the content, incorporate relevant keywords, and link to other related articles on their website.
3.  **A freelance writer is hired to write a product review for a client.** They use the skill to research the product, analyze competitor reviews, and write a detailed and unbiased review that helps readers make an informed purchasing decision.
4.  **A startup founder wants to create a knowledge base for their new software product.** They use the skill to generate a series of how-to guides and tutorials that explain how to use the different features of their product. The agent helps them create content that is clear, concise, and easy for users to understand.
5.  **An e-commerce store owner wants to optimize their product descriptions for search engines.** They use the skill to rewrite their product descriptions to be more engaging and keyword-rich. The agent helps them highlight the key features and benefits of each product in a way that appeals to both customers and search engines.
6.  **A food blogger wants to create a recipe post that will rank on the first page of Google.** They use the skill to find a popular recipe keyword, analyze the top-ranking recipes, and create a unique and delicious recipe that stands out from the competition. The agent helps them format the recipe correctly and include beautiful images to make it more appealing.
